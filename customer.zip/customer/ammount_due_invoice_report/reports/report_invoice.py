from odoo import fields, models, api

class SaleExcelReport(models.AbstractModel):
    _name = 'report.ammount_due_invoice_report.excel_report1'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, lines):   
        sheet = workbook.add_worksheet('Invoice report')
        bold = workbook.add_format({'bold': True, 'align': 'center', 'border': True})
        title = workbook.add_format({'bold': True, 'align': 'center', 'font_size': 20, 'border': True})
        invoice = self.env['account.move'].search([('move_type', '=', 'out_invoice')])
        row = 3
        serial_number = 1
        sheet.merge_range('A1:G1', 'Invoice Report', title)
        sheet.write('A2', 'Sl.No', bold)
        sheet.write('B2', 'Customer Name', bold)
        sheet.write('C2', 'Total Amount', bold)
        sheet.write('D2', 'Paid', bold)
        sheet.write('E2', 'Due', bold)
        sheet.write('F2', 'Invoices', bold)
        sheet.write('G2', 'Sale against', bold)

        customer_totals = {}

        for order in invoice:
            sale_order = self.env['sale.order'].search([('invoice_ids', '=', order.id)])
            customer_name = order.partner_id.name
            if customer_name not in customer_totals:
                customer_totals[customer_name] = {
                    'total_amount': 0.0,
                    'total_paid': 0.0,
                    'total_due': 0.0,
                    'Invoices': '',
                    'Sale_against': '',
                }

            customer_totals[customer_name]['total_amount'] += order.amount_total_signed
            amount_paid = order.amount_total_signed - order.amount_residual
            customer_totals[customer_name]['total_paid'] += amount_paid
            customer_totals[customer_name]['total_due'] += order.amount_residual

            if sale_order:
                customer_totals[customer_name]['Sale_against'] += (sale_order.name +',')
            else:
                customer_totals[customer_name]['Sale_against'] = ''

            customer_totals[customer_name]['Invoices'] += (order.name+',')

        for customer_name, totals in customer_totals.items():
            if any(totals.values()):
                sheet.write('A%s' % row, serial_number)
                serial_number += 1
                sheet.write('B%s' % row, customer_name)
                sheet.set_column("B:B", 15)
                sheet.write('C%s' % row, totals['total_amount'])
                sheet.set_column("C:C", 15)
                sheet.write('D%s' % row, totals['total_paid'])
                sheet.set_column("D:D", 15)
                sheet.write('E%s' % row, totals['total_due'])
                sheet.set_column("E:E", 15)
                sheet.write('F%s' % row, totals['Invoices'])
                sheet.set_column("F:F", 15)
                sheet.write('G%s' % row, totals['Sale_against'])
                sheet.set_column("G:G", 15)
                row += 1
