from odoo import fields, models, api

class SaleExcelReport(models.AbstractModel):
    _name = 'report.ammount_due_invoice_report.excel_report2'
    _inherit = 'report.report_xlsx.abstract'
    
    
    def generate_xlsx_report(self, workbook, data, lines):   
        sheet = workbook.add_worksheet('Invoice report')
        bold = workbook.add_format({'bold': True, 'align': 'center', 'border': True})
        title = workbook.add_format({'bold': True, 'align': 'center', 'font_size': 20, 'border': True})
        invoice = self.env['account.move'].search([('move_type', '=', 'out_invoice')])
        row = 3
        serial_number = 1
        sheet.merge_range('A1:G1', 'Product Report', title)
        sheet.write('A2', 'Sl.No', bold)
        sheet.write('B2', 'Product', bold)
        sheet.write('C2', 'Quantity', bold)
        sheet.write('D2', 'Total Unit Price', bold)

        product_totals = {}

        for order in invoice:
            for line in order.invoice_line_ids:
                product_name = line.product_id.name
                
                if product_name not in product_totals:
                    product_totals[product_name] = {
                        'Quantity': 0.0,
                        'Unit_Price': 0.0,
                    }

                product_totals[product_name]['Quantity'] += line.quantity
                product_totals[product_name]['Unit_Price'] += line.price_unit

        for product_name, totals in product_totals.items():
            if any(totals.values()):
                sheet.write('A%s' % row, serial_number)
                serial_number += 1
                sheet.write('B%s' % row, product_name)
                sheet.set_column("B:B", 15)
                sheet.write('C%s' % row, totals['Quantity'])
                sheet.set_column("C:C", 15)
                sheet.write('D%s' % row, totals['Unit_Price'])
                sheet.set_column("D:D", 15)
              
                row += 1
