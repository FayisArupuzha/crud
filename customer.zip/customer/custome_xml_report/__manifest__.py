{
    'name': 'Odoo 16 Report_excel_1234567',
    'author': 'ramu',
    'category': 'Invoice_xlx',
    'version': '16.0.0.1',
    'description': """ """,
    'summary': 'new filed creation in odoo.sale',
    # 'sequence': 11,
    # 'website': 'https://www.odoomates.tech',
    'depends': ['sale','report_xlsx'],
    'license': 'LGPL-3',
    'data': [
        # "reports/xlsx_report.xml",
        'security/ir.model.access.csv',
        'security/security.xml',
        'wizard/wizard.xml',
        'views/menu.xml',
        "reports/xlsx_report.xml",
        
        
        
    ],
}    