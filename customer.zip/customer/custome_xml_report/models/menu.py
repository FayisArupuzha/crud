from odoo import models, fields,api

class Purchase_order_custome(models.Model):
    _inherit = 'sale.order'
    
    