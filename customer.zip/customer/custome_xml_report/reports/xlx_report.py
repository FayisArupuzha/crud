from odoo import fields, models, api

class FirstReport(models.AbstractModel):
    _name = 'report.custome_xml_report.openacademy_xlsx_report'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, lines):
        sheet = workbook.add_worksheet('sale order report')
        bold = workbook.add_format({'bold': True, 'align': 'center', 'border': True})
        title = workbook.add_format({'bold': True, 'align': 'center', 'font_size': 10, 'border': True})

      
        date_from = data['form']['date_from']
        date_to = data['form']['date_to']
        responsible_id = data['form']['responsible_id']
        
        
        
        variable = 0
        domain = []
        
        if self.env.user.has_group('custome_xml_report.overtime_manager_access_excel_123') or  self.env.user.has_group('custome_xml_report.overtime_user_access_excel'):
            variable=1
            if date_from:
                domain.append(('date_order', '>=', date_from))
            if date_to:
                domain.append(('date_order', '<=', date_to))
            if responsible_id:
                domain.append(('user_id', '=', responsible_id))
            if not self.env.user.has_group("custome_xml_report.overtime_manager_access_excel_123"):
                domain.append(('user_id','=',self.env.user.id))
           
        # domain.append(('state','=','sale'))
        if variable==1:
            sale_orders = self.env['sale.order'].search(domain)

            
            row = 3
            serial_number = 1
            sheet.merge_range('A1:F1', 'sale order', title)
            sheet.write('A2', 'Sl.No', bold)
            sheet.write('B2', 'Sale.No', bold)
            sheet.write('C2', 'Date', bold)
            sheet.write('D2', 'Amount', bold)
            sheet.write('E2', 'Sale_person', bold)
            
            
            amount_total=0
            for order in sale_orders:
                order_date = order.date_order
                date_d = order_date.strftime('%Y-%m-%d')

                sheet.write('A%s' % row, serial_number)
                serial_number += 1
                sheet.write('B%s' % row, order.name)
                sheet.write('C%s' % row, date_d)
                sheet.set_column("C:C",15)
                sheet.write('D%s' % row, order.amount_total)
                sheet.write('E%s' % row, order.user_id.name)
                sheet.set_column("E:E",15)
                row += 1
            amount_total =sum(sale_orders.mapped("amount_total"))
            sheet.write('C%s' % row, "TOTAL")
            sheet.write('D%s' % row, amount_total)
            
        else:
            print()