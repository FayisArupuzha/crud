{
    'name': 'Odoo 16 Report_invoice_fayis1212',
    'author': 'Fayis',
    'category': 'Invoice',
    'version': '16.0.0.1',
    'description': """ """,
    'summary': 'new filed creation in odoo.sale',
    # 'sequence': 11,
    # 'website': 'https://www.odoomates.tech',
    'depends': ['account'],
    'license': 'LGPL-3',
    # 'data': [
    #     "reports/invoice_pdf_report.xml",
    #     "reports/invoice_header_footer.xml",
    #     "reports/papper_format.xml",
        
        
    # ],
}    