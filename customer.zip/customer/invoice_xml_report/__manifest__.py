{
    'name': 'Odoo 16 Report_invoice_excel_report',
    'author': 'Muhammed fayis',
    'category': 'Invoice_xlx',
    'version': '16.0.0.1',
    'description': """ """,
    'summary': 'new filed creation in odoo.sale',
    # 'sequence': 11,
    # 'website': 'https://www.odoomates.tech',
    'depends': ['account','report_xlsx'],
    'license': 'LGPL-3',
    'data': [
        'security/ir.model.access.csv',
        'wizard/wizard.xml',
        'views/menu.xml',
        'reports/invoice_excel_report.xml',
        
        
        
    ],
}    