from odoo import fields, models, api

class FirstReport(models.AbstractModel):
    _name = 'report.invoice_xml_report.openacademy_invoice_xlsx_report'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, lines):   
        sheet = workbook.add_worksheet('Invoice report')
        bold = workbook.add_format({'bold': True, 'align': 'center', 'border': True})
        title = workbook.add_format({'bold': True, 'align': 'center', 'font_size': 10, 'border': True})

    
        variable = 0
        domain = []
        
        date_from = data['form']['date_from']
        date_to = data['form']['date_to']
        
        
      
        # if variable==1:
        invoice = self.env['account.move'].search([('move_type','=','out_invoice'),('state','!=','draft')])
        # sale_status=self.env['sale_order'].search([('invoice_origin','in','state')])

        
        row = 3
        serial_number = 1
        sheet.merge_range('A1:F1', 'Sale Invoice', title)
        sheet.write('A2', 'Sl.No', bold)
        sheet.write('B2', 'Invoice.No', bold)
        sheet.write('C2', 'Invoice Date', bold)
        sheet.write('D2', 'Invoice Amount', bold)
        sheet.write('E2', 'State', bold)
        sheet.write('F2', 'Relation', bold)
        sheet.write('G2', 'Sale Status', bold)
        sheet.write('H2', 'Avalialbe product ', bold)
        
        
        amount_total=0
        for order in invoice:
            order_date = order.invoice_date
            sale_order = self.env['sale.order'].search([('invoice_ids','=',order.id)])
            date_d = order_date.strftime('%Y-%m-%d') if order_date else False

            sheet.write('A%s' % row, serial_number)
            serial_number += 1
            sheet.write('B%s' % row, order.name)
            sheet.set_column("B:B",15)
            sheet.write('C%s' % row, date_d)
            sheet.set_column("C:C",15)
            sheet.write('D%s' % row, order.amount_total_signed)
            sheet.set_column("D:D",15)
            sheet.write('E%s' % row, order.state)
            sheet.set_column("E:E",15)
            sheet.write('F%s' % row, sale_order.name)
            sheet.set_column("F:F",15)
            

            # sheet.write('H%s' % row, order.invoice_line_ids.product_id.qty_available)
            sheet.set_column("H:H",15)
            
          
            sheet.write('G%s' % row, sale_order.state)
            sheet.set_column("G:G", 15)
            for line in order.invoice_line_ids:
                row+=1
                sheet.write('B%s' % row, line.product_id.name)
                sheet.write('D%s' % row, line.price_subtotal)
                sheet.write('H%s' % row, line.product_id.qty_available)


            row += 1
        amount_total =sum(invoice.mapped("amount_total"))
        sheet.write('C%s' % row, "TOTAL")
        sheet.write('D%s' % row, amount_total)
        
    