from odoo import models, fields, api


class OpenAcademyPDFReport(models.TransientModel):
    _name = 'excel_invoice_fayis'

    date_from = fields.Date('Date from', )
    date_to = fields.Date('Date to', )
    # course_ids = fields.Many2many('', string='Course')
    responsible_id = fields.Many2one('res.users',string="Sale person")
    
    def action_generate_xlsx_report(self):
        data = {
            'ids':self.ids,
            'model':self._name,
            'form':{'date_from': self.date_from,
                    'date_to': self.date_to,
            }
            # 'course_ids': self.course_ids.ids,
            # 'responsible_id': self.responsible_id.id
        }
        return self.env.ref('invoice_xml_report.action_openacademy_invoice_xlsx_report').report_action(self, data=data)