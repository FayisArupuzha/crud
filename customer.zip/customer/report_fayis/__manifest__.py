{
    'name': 'Odoo 16 Report_fayis',
    'author': 'Fayis',
    'category': 'Purchase',
    'version': '16.0.0.1',
    'description': """ """,
    'summary': 'new filed creation in odoo.sale',
    # 'sequence': 11,
    # 'website': 'https://www.odoomates.tech',
    'depends': ['purchase'],
    'license': 'LGPL-3',
    'data': [
        # 'views/vi-purchase_order.xml',
        # 'security/ir.model.access.csv',
        'reports/report_fayis.xml',
        'reports/custom_session_header_footer.xml',
        # 'reports/task_1_report.xml'
    ],
}    