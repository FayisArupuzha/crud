# from odoo import models, fields

# class Purchase_order(models.Model):
#     _name = "fayis.report"
#     _rec_name = "product_name"