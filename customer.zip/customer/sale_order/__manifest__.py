{
    'name': 'Odoo 16 Recurring Payment',
    'author': 'Odoo Mates',
    'category': 'Sale',
    'version': '16.0.0.1',
    'description': """ """,
    'summary': 'new filed creation in odoo.sale',
    # 'sequence': 11,
    # 'website': 'https://www.odoomates.tech',
    'depends': ['sale'],
    'license': 'LGPL-3',
    'data': [
        'views/sale_order.xml',
    ],
}    