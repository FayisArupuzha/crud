from odoo import fields, models, api

class SaleExcelReport(models.AbstractModel):
    _name = 'report.sale_order_excel_report.sale_excel_report'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, lines):   
        sheet = workbook.add_worksheet('Invoice report')
        bold = workbook.add_format({'bold': True, 'align': 'center', 'border': True})
        title = workbook.add_format({'bold': True, 'align': 'center', 'font_size': 20, 'border': True})

    
        
        date_from = data['form']['date_from']
        date_to = data['form']['date_to']
        
        invoice = self.env['sale.order'].search([])
        row = 3
        serial_number = 1
        sheet.merge_range('A1:G1', 'Sale Report', title)
        sheet.write('A2', 'Sl.No', bold)
        sheet.write('B2', 'Serial Name', bold)
        sheet.write('C2', 'Date', bold)
        sheet.write('D2', 'Sale person', bold)
        sheet.write('E2', 'Total Ammount', bold)
        sheet.write('F2', 'Invoice', bold)
        sheet.write('G2', 'Delivery', bold)
        
        
        amount_total=0
        for order in invoice:
            create_date = order.create_date
            delivery = order.commitment_date
            sale_order = self.env['sale.order'].search([('invoice_ids','=',order.id)])
            date_d = create_date.strftime('%Y-%m-%d') if create_date else False
            date_dd = delivery.strftime('%Y-%m-%d') if delivery else False

            sheet.write('A%s' % row, serial_number)
            serial_number += 1
            sheet.write('B%s' % row, order.name)
            sheet.set_column("B:B",15)
            sheet.write('C%s' % row, date_d)
            sheet.set_column("C:C",15)
            sheet.write('D%s' % row, order.user_id.name)
            sheet.set_column("D:D",15)
            sheet.write('E%s' % row, order.amount_total)
            sheet.set_column("E:E",15)
            invoice_string=''
            for inv in order.invoice_ids:
                invoice_string += ','+inv.name
            sheet.write('F%s' % row, invoice_string)
            sheet.set_column("F:F",25)
            picking =''
            for pk in order.picking_ids:
                picking += ','+pk.name
            sheet.write('G%s' % row, picking)
            sheet.set_column("G:G",25)
            
           
            
            


            row += 1
        # amount_total =sum(invoice.mapped("amount_total"))
        # sheet.write('C%s' % row, "TOTAL")
        # sheet.write('D%s' % row, amount_total)
        
    
