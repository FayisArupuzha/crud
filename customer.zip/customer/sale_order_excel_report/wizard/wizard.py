from odoo import models, fields, api


class ExcelReport(models.TransientModel):
    _name = 'sale_order_excel_report'

    date_from = fields.Date('Date from',)
    date_to = fields.Date('Date to',)
    
    
    def action_generate_xlsx_report(self):
        data = {
            'ids':self.ids,
            'model':self._name,
            'form':{'date_from': self.date_from,
                    'date_to': self.date_to,
            }
            # 'course_ids': self.course_ids.ids,
            # 'responsible_id': self.responsible_id.id
        }
        return self.env.ref('sale_order_excel_report.action_openacademy_sale_excel_report').report_action(self, data=data)