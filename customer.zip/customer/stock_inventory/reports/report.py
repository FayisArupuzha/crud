from odoo import fields, models, api

class SaleExcelReport(models.AbstractModel):
    _name = 'report.stock_inventory.stock_report'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, lines):   
        sheet = workbook.add_worksheet('Invoice report')
        bold = workbook.add_format({'bold': True, 'align': 'center', 'border': True})
        title = workbook.add_format({'bold': True, 'align': 'center', 'font_size': 20, 'border': True})
        invoice = self.env['stock.picking'].search([])
        row = 3
        serial_number = 1
        sheet.merge_range('A1:G1', 'Stock Report', title)
        sheet.write('A2', 'Sl.No', bold)
        sheet.write('B2', 'Product', bold)
        sheet.write('C2', 'Total In', bold)
        sheet.write('D2', 'Total Out', bold)
        sheet.write('E2', 'Avialble', bold)
       