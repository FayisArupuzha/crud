from odoo import models, fields, api


class ExcelReport(models.TransientModel):
    _name = 'stock_excel_report'

    date_from = fields.Date('Date from',)
    date_to = fields.Date('Date to',)
    
    
    
    def action_generate_xlsx_report(self):
        data = {
            'ids':self.ids,
            'model':self._name,
            'form':{'date_from': self.date_from,
                    'date_to': self.date_to,
            }
          
        }
        return self.env.ref('stock_inventory.action_openacademy_stock_excel_report').report_action(self, data=data)